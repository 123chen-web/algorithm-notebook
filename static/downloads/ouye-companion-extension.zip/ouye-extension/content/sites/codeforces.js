/* Codeforces 适配器：
 * codeforces.com/problemset/problem/{contestId}/{index}
 * codeforces.com/contest/{contestId}/problem/{index}
 *
 * 选择器维护（最后核对：2026-10-08，静态推断，未在真实页面验证）：
 *  只改 SELECTORS，不要改下面的提取逻辑。
 *  CF 题目页不直接展示难度（rating 在题库列表页），difficulty 恒为空；
 *  tags（.tag-box）仅在用户已通过该题或特定条件下可见，拿不到就降级。
 */
"use strict";

(function registerCodeforces() {
  const SELECTORS = {
    statement: "#problem-statement",
    titleInHeader: ".header .title",
    tags: ".tag-box",
    titleSuffixes: [" - Codeforces"],
  };

  function textOf(el) {
    return (el && el.textContent ? el.textContent : "").trim();
  }

  AdapterRegistry.register({
    id: "codeforces",
    source: "codeforces",
    SELECTORS,

    detect(loc) {
      const host = (loc.hostname || "").toLowerCase();
      const path = loc.pathname || "";
      const isCf = host === "codeforces.com" || host.endsWith(".codeforces.com");
      if (!isCf) return false;
      return (
        /^\/problemset\/problem\/\d+\/[A-Za-z0-9]+/.test(path) ||
        /^\/contest\/\d+\/problem\/[A-Za-z0-9]+/.test(path)
      );
    },

    sourceId(loc) {
      const path = loc.pathname || "";
      let m =
        /^\/problemset\/problem\/(\d+)\/([A-Za-z0-9]+)/.exec(path) ||
        /^\/contest\/(\d+)\/problem\/([A-Za-z0-9]+)/.exec(path);
      return m ? m[1] + m[2].toUpperCase() : "";
    },

    extract(doc, url) {
      const degraded = [];
      const loc = new URL(url);
      let title = "";
      let content = "";
      let ps = null;
      try {
        ps = doc.querySelector(SELECTORS.statement);
      } catch (e) {
        ps = null;
      }
      if (ps) {
        try {
          title = textOf(ps.querySelector(SELECTORS.titleInHeader));
          const clone = ps.cloneNode(true);
          const header = clone.querySelector(".header");
          if (header && header.remove) header.remove();
          content = textOf(clone);
        } catch (e) {
          /* 降级到 document.title */
        }
      }
      if (!title) {
        let t = (doc && doc.title) || "";
        for (const s of SELECTORS.titleSuffixes) {
          if (t.endsWith(s)) {
            t = t.slice(0, -s.length);
            break;
          }
        }
        title = t.trim();
      }
      if (!title) degraded.push("title");
      if (!content) degraded.push("content");
      let tags = [];
      try {
        tags = Array.from(doc.querySelectorAll(SELECTORS.tags))
          .map((a) => textOf(a).replace(/^#/, ""))
          .filter(Boolean)
          .slice(0, 20);
      } catch (e) {
        tags = [];
      }
      if (!tags.length) degraded.push("tags");
      return {
        title,
        source: "codeforces",
        source_id: this.sourceId(loc),
        url,
        difficulty: "", // CF 题目页不展示难度
        tags,
        zone_hint: "算法",
        my_status: null, // 账号信息不读取
        content,
        degraded,
      };
    },
  });
})();
