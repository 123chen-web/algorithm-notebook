/* AtCoder 适配器：atcoder.jp/contests/{contest}/tasks/{task_id}。
 *
 * 选择器维护（最后核对：2026-10-08，静态推断，未在真实页面验证）：
 *  只改 SELECTORS，不要改下面的提取逻辑。
 *  AtCoder 题目页不展示难度与标签，这两项恒为空/空数组。
 *  注意：后端 import-from-extension 的 source 白名单暂不含 atcoder，
 *  扩展侧会拦截导入并提示（见 EXT_REPORT 的后端规格建议）。
 */
"use strict";

(function registerAtcoder() {
  const SELECTORS = {
    statement: "#task-statement",
    title: "#task-statement span.h2, span.h2",
    titleSuffixes: [" - AtCoder"],
  };

  function textOf(el) {
    return (el && el.textContent ? el.textContent : "").trim();
  }

  AdapterRegistry.register({
    id: "atcoder",
    source: "atcoder",
    SELECTORS,

    detect(loc) {
      const host = (loc.hostname || "").toLowerCase();
      const path = loc.pathname || "";
      const isAc = host === "atcoder.jp" || host.endsWith(".atcoder.jp");
      return isAc && /^\/contests\/[^/]+\/tasks\/[^/]+/.test(path);
    },

    sourceId(loc) {
      const m = /^\/contests\/[^/]+\/tasks\/([^/?#]+)/.exec(loc.pathname || "");
      return m ? m[1] : "";
    },

    extract(doc, url) {
      const degraded = [];
      const loc = new URL(url);
      let title = "";
      try {
        const h = doc.querySelector(SELECTORS.title);
        title = textOf(h);
      } catch (e) {}
      if (!title) {
        let t = (doc && doc.title) || "";
        for (const s of SELECTORS.titleSuffixes) {
          if (t.endsWith(s)) {
            t = t.slice(0, -s.length);
            break;
          }
        }
        title = t.trim();
      }
      if (!title) degraded.push("title");
      let content = "";
      try {
        const st = doc.querySelector(SELECTORS.statement);
        content = textOf(st);
      } catch (e) {}
      if (!content) degraded.push("content");
      return {
        title,
        source: "atcoder",
        source_id: this.sourceId(loc),
        url,
        difficulty: "", // AtCoder 题目页不展示难度
        tags: [], // AtCoder 题目页无公开标签
        zone_hint: "算法",
        my_status: null, // 账号信息不读取
        content,
        degraded,
      };
    },
  });
})();
