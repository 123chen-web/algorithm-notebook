/* 洛谷适配器：luogu.com.cn/problem/*（含比赛内、题单内的题目页，URL 同为 /problem/题号）。
 *
 * 选择器维护（最后核对：2026-10-08，静态推断，未在真实页面验证）：
 *  只改 SELECTORS，不要改下面的提取逻辑。
 *  洛谷前端是 SPA，题目页主体异步渲染；document.title 是最稳的兜底。
 */
"use strict";

(function registerLuogu() {
  const SELECTORS = {
    // 标题候选：页面主标题 → h1 → document.title 兜底
    title: ["h1", ".problem-title", "[class*='problem-title']"],
    // 题面候选
    content: [".problem-content", "[class*='problem-content']", "article"],
    // 难度：洛谷用文字标识（入门/普及-/提高-/省选-/NOI/）
    difficulty: [".difficulty", "[class*='difficulty']"],
    // 标签链接
    tags: "a[href*='/tag']",
    // document.title 后缀（去掉站点名）
    titleSuffixes: [" - 洛谷", " - 洛谷 | 计算机科学教育新生态", "| 洛谷"],
    // 难度关键词 → 归一化
    difficultyWords: ["入门", "普及", "提高", "省选", "NOI", "IOI"],
  };

  function textOf(el) {
    return (el && el.textContent ? el.textContent : "").trim();
  }

  function firstText(doc, selectors) {
    for (const sel of selectors) {
      let el = null;
      try {
        el = doc.querySelector(sel);
      } catch (e) {
        /* 非法选择器就跳过 */
      }
      const t = textOf(el);
      if (t) return t;
    }
    return "";
  }

  function titleFromDocTitle(doc) {
    let t = (doc && doc.title) || "";
    for (const s of SELECTORS.titleSuffixes) {
      const i = t.indexOf(s);
      if (i !== -1) {
        t = t.slice(0, i);
        break;
      }
    }
    return t.trim();
  }

  AdapterRegistry.register({
    id: "luogu",
    source: "luogu",
    SELECTORS,

    detect(loc) {
      const host = (loc.hostname || "").toLowerCase();
      const path = loc.pathname || "";
      const isLuogu = host === "luogu.com.cn" || host.endsWith(".luogu.com.cn");
      return isLuogu && /^\/problem\/[A-Za-z0-9]+/.test(path);
    },

    sourceId(loc) {
      const m = /^\/problem\/([A-Za-z0-9]+)/.exec(loc.pathname || "");
      return m ? m[1].toUpperCase() : "";
    },

    extract(doc, url) {
      const degraded = [];
      let title = firstText(doc, SELECTORS.title) || titleFromDocTitle(doc);
      if (!title) degraded.push("title");
      const content = firstText(doc, SELECTORS.content);
      if (!content) degraded.push("content");
      const diffRaw = firstText(doc, SELECTORS.difficulty);
      let difficulty = "";
      for (const w of SELECTORS.difficultyWords) {
        if (diffRaw.indexOf(w) !== -1) {
          difficulty = w;
          break;
        }
      }
      let tags = [];
      try {
        tags = Array.from(doc.querySelectorAll(SELECTORS.tags))
          .map((a) => textOf(a))
          .filter(Boolean)
          .slice(0, 20);
      } catch (e) {
        tags = [];
      }
      // my_status：涉及用户账号信息，按隐私要求不读取，恒为 null。
      return {
        title,
        source: "luogu",
        source_id: this.sourceId({ pathname: new URL(url).pathname }),
        url,
        difficulty,
        tags,
        zone_hint: "算法",
        my_status: null,
        content,
        degraded,
      };
    },
  });
})();
