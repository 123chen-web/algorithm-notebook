/* 力扣适配器：leetcode.cn/problems/* 与 leetcode.com/problems/*。
 *
 * 选择器维护（最后核对：2026-10-08，静态推断，未在真实页面验证）：
 *  只改 SELECTORS，不要改下面的提取逻辑。
 *  力扣是 SPA（切题不刷新），document.title 是最稳的兜底：
 *  中文站形如 "1. 两数之和 - 力扣（LeetCode）"，英文站形如 "1. Two Sum - LeetCode"。
 */
"use strict";

(function registerLeetcode() {
  const SELECTORS = {
    title: ['[data-cy="question-title"]', ".text-title-large", "[class*='question-title']"],
    content: [
      '[data-track-load="description_content"]',
      '[data-cy="question-description"]',
      ".question-content",
      "[class*='question-content']",
    ],
    // 难度胶囊（中英文都认）
    difficulty: [
      ".text-difficulty-easy",
      ".text-difficulty-medium",
      ".text-difficulty-hard",
      "[class*='difficulty']",
    ],
    tags: 'a[href*="/tag/"]',
    titleSuffixes: [" - 力扣（LeetCode）", " - LeetCode", " - 力扣"],
    // 题号前缀："1. 两数之和" -> "两数之和"（source_id 用 URL slug，不用这个）
    titleNumberPrefix: /^\d+\.\s*/,
  };

  function textOf(el) {
    return (el && el.textContent ? el.textContent : "").trim();
  }

  function firstText(doc, selectors) {
    for (const sel of selectors) {
      let el = null;
      try {
        el = doc.querySelector(sel);
      } catch (e) {}
      const t = textOf(el);
      if (t) return t;
    }
    return "";
  }

  function titleFromDocTitle(doc) {
    let t = (doc && doc.title) || "";
    for (const s of SELECTORS.titleSuffixes) {
      if (t.endsWith(s)) {
        t = t.slice(0, -s.length);
        break;
      }
    }
    return t.replace(SELECTORS.titleNumberPrefix, "").trim() || t.trim();
  }

  function normalizeDifficulty(raw) {
    if (/简单|easy/i.test(raw)) return "简单";
    if (/中等|medium/i.test(raw)) return "中等";
    if (/困难|hard/i.test(raw)) return "困难";
    return "";
  }

  AdapterRegistry.register({
    id: "leetcode",
    source: "leetcode", // detect 时再按 hostname 细分为 leetcode / leetcode-cn
    SELECTORS,

    detect(loc) {
      const host = (loc.hostname || "").toLowerCase();
      const path = loc.pathname || "";
      const isLc =
        host === "leetcode.com" ||
        host.endsWith(".leetcode.com") ||
        host === "leetcode.cn" ||
        host.endsWith(".leetcode.cn");
      return isLc && /^\/problems\/[^/]+/.test(path);
    },

    sourceName(loc) {
      const host = (loc.hostname || "").toLowerCase();
      return host === "leetcode.cn" || host.endsWith(".leetcode.cn")
        ? "leetcode-cn"
        : "leetcode";
    },

    sourceId(loc) {
      const m = /^\/problems\/([^/]+)/.exec(loc.pathname || "");
      return m ? m[1] : "";
    },

    extract(doc, url) {
      const degraded = [];
      const loc = new URL(url);
      const source = this.sourceName(loc);
      let title = firstText(doc, SELECTORS.title) || titleFromDocTitle(doc);
      if (!title) degraded.push("title");
      const content = firstText(doc, SELECTORS.content);
      if (!content) degraded.push("content");
      const difficulty = normalizeDifficulty(firstText(doc, SELECTORS.difficulty));
      let tags = [];
      try {
        tags = Array.from(doc.querySelectorAll(SELECTORS.tags))
          .map((a) => textOf(a))
          .filter(Boolean)
          .slice(0, 20);
      } catch (e) {
        tags = [];
      }
      let language = "";
      try {
        const btn = doc.querySelector('button[aria-label*="language" i]');
        language = textOf(btn);
      } catch (e) {}
      return {
        title,
        source,
        source_id: this.sourceId(loc),
        url,
        difficulty,
        tags,
        zone_hint: "算法",
        my_status: null, // 账号信息不读取
        content,
        language,
        degraded,
      };
    },
  });
})();
